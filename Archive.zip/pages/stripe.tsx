import PaymentPage from './paymentPage';

const Payment: React.FC = () => {
  return <PaymentPage />;
};

export default Payment;
