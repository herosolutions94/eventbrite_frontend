declare module '@g-loot/react-tournament-brackets';
